import React, { useContext } from "react";
import { useState } from "react";
import Container from "./components/Container";
import Favorite from "./components/Favorite";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Login from "./components/Login";
import { FavoriteContext } from "./Context/FavoriteContext";
import "./styles.css";
const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const { favorites } = useContext(FavoriteContext);
  debugger;
  const handelLogin = (user, pass) => {
    debugger;
    if (user === "Saswat" && pass === "Saswat123@") {
      setIsLoggedIn(true);
    }
  };
  return (
    <div>
      <h1>Recipe Finder</h1>

      <Router>
        <nav className="navbar">
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/login">Login</Link>
            </li>
            {isLoggedIn && (
              <li>
                <Link to="/favorites">Favorites</Link>
              </li>
            )}
          </ul>
        </nav>
        <Routes>
          <Route path="/" element={<Container />}></Route>
          <Route
            path="/favorites"
            element={<Favorite favorites={favorites} />}
          ></Route>

          <Route
            path="/login"
            element={
              <Login handelLogin={handelLogin} isLoggedIn={isLoggedIn} />
            }
          ></Route>
        </Routes>
      </Router>
    </div>
  );
};

export default App;
