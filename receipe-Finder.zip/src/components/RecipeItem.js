import React, { useContext } from "react";
import { FavoriteContext } from "../Context/FavoriteContext";

const RecipeItem = ({ recipe }) => {
  const { favorites, addFavorite, removeFavorite } =
    useContext(FavoriteContext);
  return (
    <div className="item">
      <h3>{recipe.label}</h3>
      <img src={recipe.image} alt={recipe.label} />
      <p>Calories: {Math.round(recipe.calories)}</p>
      <a href={recipe.url} target="_blank" rel="noopener noreferrer">
        View Recipe
      </a>
      {favorites.includes(recipe) ? (
        <button type="button" onClick={() => removeFavorite(recipe)}>
          Remove Favorite
        </button>
      ) : (
        <button type="button" onClick={() => addFavorite(recipe)}>
          Add to Favorites
        </button>
      )}
    </div>
  );
};

export default RecipeItem;
