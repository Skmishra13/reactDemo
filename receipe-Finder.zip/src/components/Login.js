import { useRef } from "react";
const Login = (props) => {
  const userRef = useRef();
  const passRef = useRef();

  return props.isLoggedIn ? (
    <p>Login Successful</p>
  ) : (
    <div className="login-container">
      <h2>Login Page</h2>
      <form className="login-form">
        <div className="input-group">
          <label htmlFor="Username">Username</label>
          <input ref={userRef} type="text" placeholder="UserName" />
        </div>
        <div className="input-group">
          <label htmlFor="Password">Password</label>
          <input ref={passRef} type="password" placeholder="Password" />
        </div>
        <button
          type="button"
          onClick={() =>
            props.handelLogin(userRef.current.value, passRef.current.value)
          }
        >
          Login
        </button>
      </form>
    </div>
  );
};

export default Login;
