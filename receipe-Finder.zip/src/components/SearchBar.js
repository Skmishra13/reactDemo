import React from "react";
import { useDispatch } from "react-redux";
import { setSearchQuery, fetchRecipes } from "../actions/actions";

const SearchBar = () => {
  const dispatch = useDispatch();

  const handleSearch = (e) => {
    const query = e.target.value;
    dispatch(setSearchQuery(query));
    if (query) {
      dispatch(fetchRecipes(query));
    }
  };

  return (
    <div className="search-container">
      <input
        id="search"
        type="text"
        placeholder="Search for recipes..."
        onChange={handleSearch}
      />
    </div>
  );
};

export default SearchBar;
