import SearchBar from "./SearchBar";
import RecipeList from "./RecipeList";
import { Provider } from "react-redux";
import store from "../store/store";
const Container = () => {
  return (
    <Provider store={store}>
      <div>
        <SearchBar />
        <RecipeList />
      </div>
    </Provider>
  );
};

export default Container;
