import React from "react";
import { useSelector } from "react-redux";
import RecipeItem from "./RecipeItem";

const RecipeList = () => {
  const recipes = useSelector((state) => state.recipes);
  const error = useSelector((state) => state.error);

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="items-grid">
      {recipes.map(({ recipe }) => (
        <RecipeItem key={recipe.label} recipe={recipe} />
      ))}
    </div>
  );
};

export default RecipeList;
