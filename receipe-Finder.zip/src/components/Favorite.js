import RecipeItem from "./RecipeItem";
const Favorite = (props) => {
  debugger;
  return (
    <div className="items-grid" style={{ marginTop: "20px" }}>
      {props.favorites.map((fav, i) => (
        <RecipeItem key={i} recipe={fav} />
      ))}
    </div>
  );
  // <h1>fav</h1>
};
export default Favorite;
