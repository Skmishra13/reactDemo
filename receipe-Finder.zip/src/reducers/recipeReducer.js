import {
  SET_SEARCH_QUERY,
  FETCH_RECIPES_SUCCESS,
  FETCH_RECIPES_FAILURE,
} from "../actions/actions";

const initialState = {
  searchQuery: "",
  recipes: [],
  error: null,
};

const recipeReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_SEARCH_QUERY:
      return { ...state, searchQuery: action.payload };
    case FETCH_RECIPES_SUCCESS:
      return { ...state, recipes: action.payload };
    case FETCH_RECIPES_FAILURE:
      return { ...state, error: action.payload };
    default:
      return state;
  }
};

export default recipeReducer;
