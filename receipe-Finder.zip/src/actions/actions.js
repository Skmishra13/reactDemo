import axios from "axios";

export const SET_SEARCH_QUERY = "SET_SEARCH_QUERY";
export const FETCH_RECIPES_SUCCESS = "FETCH_RECIPES_SUCCESS";
export const FETCH_RECIPES_FAILURE = "FETCH_RECIPES_FAILURE";

const APP_ID = "d32033a1";
const APP_KEY = "34da53a1c8d834577ce7f926f5a69bab";
const BASE_URL = "https://api.edamam.com/search";

export const setSearchQuery = (query) => ({
  type: SET_SEARCH_QUERY,
  payload: query,
});

export const fetchRecipes = (query) => {
  return (dispatch) => {
    axios
      .get(`${BASE_URL}?q=${query}&app_id=${APP_ID}&app_key=${APP_KEY}`)
      .then((response) => {
        dispatch({ type: FETCH_RECIPES_SUCCESS, payload: response.data.hits });
      })
      .catch((error) => {
        dispatch({ type: FETCH_RECIPES_FAILURE, payload: error.message });
      });
  };
};
